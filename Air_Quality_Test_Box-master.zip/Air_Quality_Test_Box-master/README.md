Air Quality Test Box
----------------

Air Quality Test Box is an open source machine for detect air quality.


![](http://www.seeedstudio.com/recipe/img/recipe/seeed-recipe-35-20130711084125.png)

![](http://www.seeedstudio.com/recipe/img/recipe/seeed-recipe-35-20130711084215.png)

More details: http://www.instructables.com/id/Air-Quality-Test-Box

### Usage:
1. Place SeeedOLED directory at your arduino libraries directory if you have no SeeedOLED installed yet;
2. Open Air_monitor.ino with Arduino IDE

----

This demo is licensed under [The MIT License](http://opensource.org/licenses/mit-license.php). Check License.txt for more information.<br>

Contributing to this software is warmly welcomed. You can do this basically by<br>
[forking](https://help.github.com/articles/fork-a-repo), committing modifications and then [pulling requests](https://help.github.com/articles/using-pull-requests) (follow the links above<br>
for operating guide). Adding change log and your contact into file header is encouraged.<br>
Thanks for your contribution.

Seeed Studio is an open hardware facilitation company based in Shenzhen, China. <br>
Benefiting from local manufacture power and convenient global logistic system, <br>
we integrate resources to serve new era of innovation. Seeed also works with <br>
global distributors and partners to push open hardware movement.<br>





[![Analytics](https://ga-beacon.appspot.com/UA-46589105-3/Air_Quality_Test_Box)](https://github.com/igrigorik/ga-beacon)
